import { Component, OnInit, NgModule } from '@angular/core';
import { UsuariosService } from 'src/app/services/usuarios.service';


@Component({
  selector: 'app-usuarios-list',
  templateUrl: './usuarios-list.component.html',
  styleUrls: ['./usuarios-list.component.css']
})
export class UsuariosListComponent implements OnInit {
  

  usuarios: any;
  currentUsuario = null;
  currentIndex = -1;
  noUsuario = '';
  icSituacao='';
  icPerfil_acesso='';
  nome1 ='';
  constructor(private usuariosService: UsuariosService) { }

  ngOnInit(): void {
    this.retrieveUsuarios();
  }
  
  retrieveUsuarios(): void {
    this.usuariosService.getAll()
      .subscribe(
        data => {
          this.usuarios = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }
  
  refreshList(): void {
    this.retrieveUsuarios();
    this.currentUsuario = null;
    this.currentIndex = -1;
  }

  setActiveTutorial(usuario, index): void {
    this.currentIndex = usuario;
    this.currentIndex = index;
  }
  searchUsuario(): void {
    this.usuariosService.findByUsuario(this.noUsuario)
      .subscribe(
        data => {
          this.usuarios = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }


}
