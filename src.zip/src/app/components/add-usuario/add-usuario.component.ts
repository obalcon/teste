import { Component, OnInit } from '@angular/core';
import { UsuariosService } from 'src/app/services/usuarios.service';
@Component({
  selector: 'app-add-usuario',
  templateUrl: './add-usuario.component.html',
  styleUrls: ['./add-usuario.component.css']
})
export class AddUsuarioComponent implements OnInit {

  usuario = {
    nuCpf: '',
    noUsuario: '',
    deEmail:'',
    icSituacao:'',
    icPerfil_acesso:'',
    coFuncao:'',
    nuTelefone:''  
  };
  submitted = false;
  constructor(private usuarioService: UsuariosService) { }

  ngOnInit(): void {
  }
  
  saveUsuario(): void {
    const data = {
      nuCpf: this.usuario.nuCpf,
      noUsuario: this.usuario.noUsuario,
      de_email: this.usuario.deEmail,
      icSituacao: this.usuario.icSituacao,
      icPerfil_acesso: this.usuario.icPerfil_acesso,
      coFuncao: this.usuario.coFuncao,
      nuTelefone: this.usuario.nuTelefone
    };

    this.usuarioService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newTutorial(): void {
    this.submitted = false;
    this.usuario = {
      nuCpf: '',
      noUsuario: '',
      deEmail:'',
      icSituacao:'',
      icPerfil_acesso:'',
      coFuncao:'',
      nuTelefone:''
    };
  }

  


}
