import { Component, OnInit } from '@angular/core';
import { UsuariosService } from 'src/app/services/usuarios.service';
import { ActivatedRoute, Router } from '@angular/router';



@Component({
  selector: 'app-usuarios-details',
  templateUrl: './usuarios-details.component.html',
  styleUrls: ['./usuarios-details.component.css']
})
export class UsuariosDetailsComponent implements OnInit {

  currentUsuario = null;
  message = '';

  constructor(
    private UsuariosService: UsuariosService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.message = '';
    this.getUsuario(this.route.snapshot.paramMap.get('id'));
  }

  getUsuario(id): void {
    this.UsuariosService.get(id)
      .subscribe(
        data => {
          this.currentUsuario = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }



  updateUsuario(): void {
    this.UsuariosService.update(this.currentUsuario.id, this.currentUsuario)
      .subscribe(
        response => {
          console.log(response);
          this.message = 'O usuário foi alterado com sucesso!!';
        },
        error => {
          console.log(error);
        });
  }

  deleteUsuario(): void {
    this.UsuariosService.delete(this.currentUsuario.id)
      .subscribe(
        response => {
          console.log(response);
          this.router.navigate(['/usuarios']);
        },
        error => {
          console.log(error);
        });
  }

}
