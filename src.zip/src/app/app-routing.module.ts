import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsuariosListComponent } from './components/usuarios-list/usuarios-list.component';
import { UsuariosDetailsComponent } from './components/usuarios-details/usuarios-details.component';
import { AddUsuarioComponent } from './components/add-usuario/add-usuario.component';


const routes: Routes = [
  { path: '', redirectTo: 'usuarios', pathMatch: 'full' },
  { path: 'usuarios', component: UsuariosListComponent },
  { path: 'usuarios/:id', component: UsuariosDetailsComponent },
  { path: 'add', component: AddUsuarioComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
