package com.datainfo.teste.repository;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;


import com.datainfo.teste.model.UsuarioExterno;

public interface UsuarioExternoRepository extends JpaRepository<UsuarioExterno, String> {
	
      Page<UsuarioExterno> findByNoUsuarioAndIcSituacaoAndIcPerfil(String noUsuario,String icSituacao, Integer icPerfil,Pageable pageable);
      Page<UsuarioExterno> findByNoUsuarioAndIcSituacaoIgnoreCase(String noUsuario,String icSituacao,Pageable pageable);
      Page<UsuarioExterno> findByNoUsuarioIgnoreCase(String noUsuario,Pageable pageable);
      Page<UsuarioExterno> findByIcPerfil(Integer icPerfil,Pageable pageable);
      Page<UsuarioExterno> findByNoUsuarioAndIcPerfil(String noUsuario,Integer icPerfil,Pageable pageable);
      Page<UsuarioExterno> findByIcSituacaoAndIcPerfil(String icSituacao,Integer icPerfil,Pageable pageable); 
      Page<UsuarioExterno> findByIcSituacao(String icSituacao,Pageable pageable);
      
      
      
}
