package com.datainfo.teste.model;

public   class  Mensagem {
   
	
	public  static final  String  mn001 = "Cadastro efetuado com sucesso!";
	public  static final  String  mn005 = "Exclusão efetuada com sucesso";
	public  static final  String  mn030 = "Alteração efetuada com sucesso!";
	public  static final  String  mn031 = "Deseja realmente excluir o usuário";
	public  static final  String  mn032 = "Usuário desabilitado com sucesso!";
	public  static final  String  mn033 = "Usuário habilitado com sucesso!";
	public  static final  String  mn034 = "Operação não realizada. Usuário já incluído!";
	public  static final  String  mn035 = "Operação não realizada. Usuário já incluído!";

}
