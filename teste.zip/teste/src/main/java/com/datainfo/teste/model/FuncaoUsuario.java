package com.datainfo.teste.model;


import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "func_usu_ext")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class FuncaoUsuario {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "funcao_usuario_externo_co_funcao_seq")
	@Column(name = "co_funcao")
	private Integer coFuncao;
	
	@Column(name = "no_funcao")
	private String noFuncao;

	
	public FuncaoUsuario() {
		
	}

	public FuncaoUsuario(Integer coFuncao, String noFuncao) {
		super();
		this.coFuncao = coFuncao;
		this.noFuncao = noFuncao;
	}

	public Integer getCoFuncao() {
		return coFuncao;
	}

	public void setCoFuncao(Integer coFuncao) {
		this.coFuncao = coFuncao;
	}

	public String getNoFuncao() {
		return noFuncao;
	}

	public void setNoFuncao(String noFuncao) {
		this.noFuncao = noFuncao;
	}
	
	

}
