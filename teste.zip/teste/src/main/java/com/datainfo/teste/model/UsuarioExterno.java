package com.datainfo.teste.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "usuario_externo")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class UsuarioExterno {
	
	
	@Id
    @Column(name = "nu_cpf")
	private String nuCpf;
	
	@Column(name = "no_usuario")
    private String noUsuario;
	
	@Column(name = "de_email")
    private String deEmail;
	
	@Column(name = "ic_situacao")
	private String icSituacao;
	
	@Column(name = "ic_perfil_acesso")
	private Integer icPerfil;
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "co_funcao")
	private FuncaoUsuario coFuncao;
	
	@Column(name = "nu_telefone")
	private String  nuTelefone;
	
	public UsuarioExterno() {
		
	}

	public UsuarioExterno(String nuCpf, String noUsuario, String deEmail, String icSituacao, Integer icPerfil,
			FuncaoUsuario coFuncao2, String nuTelefone2, boolean b) {
		super();
		this.nuCpf = nuCpf;
		this.noUsuario = noUsuario;
		this.deEmail = deEmail;
		this.icSituacao = icSituacao;
		this.icPerfil = icPerfil;
		this.coFuncao = coFuncao2;
		this.nuTelefone = nuTelefone2;
	}
	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
	
	
	public String getNuCpf() {
		return nuCpf;
	}
	public void setNuCpf(String nuCpf) {
		this.nuCpf = nuCpf;
	}
	public String getNoUsuario() {
		return noUsuario;
	}
	public void setNoUsuario(String noUsuario) {
		this.noUsuario = noUsuario;
	}
	public String getDeEmail() {
		return deEmail;
	}
	public void setDeEmail(String deEmail) {
		this.deEmail = deEmail;
	}
	public String getIcSituacao() {
		return icSituacao;
	}
	public void setIcSituacao(String icSituacao) {
		this.icSituacao = icSituacao;
	}
	public Integer getIcPerfil() {
		return icPerfil;
	}
	public void setIcPerfil(Integer icPerfil) {
		this.icPerfil = icPerfil;
	}
	public FuncaoUsuario getCoFuncao() {
		return coFuncao;
	}
	public void setCoFuncao(FuncaoUsuario coFuncao) {
		this.coFuncao = coFuncao;
	}
	public String getNuTelefone() {
		return nuTelefone;
	}
	public void setNuTelefone(String nuTelefone) {
		this.nuTelefone = nuTelefone;
	}
	
	
	
}
