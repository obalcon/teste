package com.datainfo.teste.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.datainfo.teste.model.UsuarioExterno;

import com.datainfo.teste.repository.UsuarioExternoRepository;


@RestController
@RequestMapping("/api")
public class UsuarioExternoController {


	  @Autowired
	  UsuarioExternoRepository usuarioRepository;
	 

	  @GetMapping("/usuarios")
	  public ResponseEntity<Map<String, Object>> getAllUsuarios(
	        @RequestParam(required = false) String noUsuario,
	        @RequestParam(required = false) String icSituacao,
	        @RequestParam(required = false) Integer icPerfil,
	        @RequestParam(defaultValue = "0") int page,
	        @RequestParam(defaultValue = "3") int size
	      ) {

	    try {
	      List<UsuarioExterno> usuarios = new ArrayList<UsuarioExterno>();
	      Pageable paging = PageRequest.of(page, size);
	      
	      Page<UsuarioExterno> pageUsus;
	      if ( (noUsuario == null ) && (icSituacao == null) && (icPerfil == null))
	    	  pageUsus = usuarioRepository.findAll(paging);
	      else {
	    	  
	    	  if ((noUsuario != null ) && (icSituacao != null) && (icPerfil != null)) {
	    		  pageUsus = usuarioRepository.findByNoUsuarioAndIcSituacaoIgnoreCase(noUsuario,icSituacao, paging);
	    	  }else  if ( (noUsuario != null ) && (icSituacao != null) )
	    		  pageUsus = usuarioRepository.findByNoUsuarioAndIcSituacaoIgnoreCase(noUsuario,icSituacao, paging);
	    	  else  if ( (noUsuario != null ) && (icPerfil != null) )
	    		  pageUsus = usuarioRepository.findByNoUsuarioAndIcPerfil(noUsuario,icPerfil, paging);
	    	  else if ( (icSituacao != null ) && (icPerfil != null) )
	    		  pageUsus = usuarioRepository.findByIcSituacaoAndIcPerfil(icSituacao,icPerfil, paging);
	    	  else if (icSituacao != null  )
	    		  pageUsus = usuarioRepository.findByIcSituacao(icSituacao, paging);
	    	  else
	    		  pageUsus = usuarioRepository.findByIcPerfil(icPerfil, paging);
	      }
	    	  
	    	  
	      usuarios = pageUsus.getContent();

	      if (pageUsus.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }

	      Map<String, Object> response = new HashMap<>();
	      response.put("usuarios", usuarios);
	      response.put("currentPage", pageUsus.getNumber());
	      response.put("totalItems", pageUsus.getTotalElements());
	      response.put("totalPages", pageUsus.getTotalPages());

	      return new ResponseEntity<>(response, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	 
	  
	  @PostMapping("/usuarios")
	  public ResponseEntity<UsuarioExterno> createUsuario(@RequestBody UsuarioExterno usuarioParam  ) {
	    try {
	     Optional<UsuarioExterno> usuarioAux = usuarioRepository.findById(usuarioParam.getNuCpf());
	      if(usuarioAux == null) {
	    	 if(usuarioParam.getNuCpf().matches("[0-9]+")) {
	    	  	    		 
	          UsuarioExterno _tutorial = usuarioRepository
		          .save(new UsuarioExterno(usuarioParam.getNuCpf(),
				  				   usuarioParam.getNoUsuario(),
				  				   usuarioParam.getDeEmail(),
				  				   usuarioParam.getIcSituacao() ,
				  				   usuarioParam.getIcPerfil(),
				  				   usuarioParam.getCoFuncao(),
				  				   usuarioParam.getNuTelefone(), false));
		      return new ResponseEntity<>(_tutorial, HttpStatus.CREATED);
	    	 }else {
	    		 return new ResponseEntity<>(usuarioParam, HttpStatus.INTERNAL_SERVER_ERROR); //botar o erro aqui
	    	 }
	      }else {
	    	  return new ResponseEntity<>(usuarioParam, HttpStatus.INTERNAL_SERVER_ERROR); //botar o erro aqui
	      }
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	  
	  @DeleteMapping("/usuarios/{id}")
	  public ResponseEntity<HttpStatus> deleteUsuario(@PathVariable("id") String id) {
	    try {
	    	usuarioRepository.deleteById(id);
	      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    } catch (Exception e) {
	      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	  
	  @PutMapping("/usuarios/updateHabilitado/{id}")
	  public ResponseEntity<UsuarioExterno> updateHabilitado(@PathVariable("id") String id) {
	    Optional<UsuarioExterno> usuario = usuarioRepository.findById(id);

	    if (usuario.isPresent()) {
	      UsuarioExterno _usuario = usuario.get();
	      _usuario.setIcSituacao("A");
	      return new ResponseEntity<>(usuarioRepository.save(_usuario), HttpStatus.OK);
	    } else {
	      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	  }
	  @PutMapping("/usuarios/updatedesHabilitado/{id}")
	  public ResponseEntity<UsuarioExterno> updatedesHabilitado(@PathVariable("id") String id) {
	    Optional<UsuarioExterno> usuario = usuarioRepository.findById(id);

	    if (usuario.isPresent()) {
	      UsuarioExterno _usuario = usuario.get();
	      _usuario.setIcSituacao("I");
	      return new ResponseEntity<>(usuarioRepository.save(_usuario), HttpStatus.OK);
	    } else {
	      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	  }
	  @GetMapping("/usuarios/{id}")
	  public ResponseEntity<UsuarioExterno> getUsuarioById(@PathVariable("id") String id) {
	    Optional<UsuarioExterno> usuario = usuarioRepository.findById(id);

	    if (usuario.isPresent()) {
	      return new ResponseEntity<>(usuario.get(), HttpStatus.OK);
	    } else {
	      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	  }
	
	}

