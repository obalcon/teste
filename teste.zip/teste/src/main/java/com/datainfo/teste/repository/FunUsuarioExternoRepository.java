package com.datainfo.teste.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datainfo.teste.model.FuncaoUsuario;


public interface FunUsuarioExternoRepository extends JpaRepository<FuncaoUsuario,Integer > {
	
	 List<FuncaoUsuario> findByNoFuncao(String no_funcao);

}
